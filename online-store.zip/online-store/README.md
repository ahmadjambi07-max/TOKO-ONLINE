# 🛍️ Aplikasi Online Store (React + Node.js + MongoDB)

Aplikasi toko online sederhana dengan fitur:
- Katalog produk & keranjang belanja
- Registrasi & login user (JWT)
- Halaman admin: kelola produk (CRUD) & kelola status pesanan

## Struktur Folder
```
online-store/
├── backend/     -> API server (Express + MongoDB)
└── frontend/    -> Aplikasi React
```

## Cara Menjalankan di VS Code

### 1. Siapkan MongoDB
Pilih salah satu:
- **MongoDB Atlas** (gratis, cloud): buat cluster di https://www.mongodb.com/cloud/atlas lalu ambil connection string-nya.
- **MongoDB lokal**: install MongoDB Community Server di komputer kamu.

### 2. Jalankan Backend
```bash
cd backend
npm install
cp .env.example .env
```
Buka file `.env`, isi `MONGO_URI` dengan connection string MongoDB kamu, dan `JWT_SECRET` dengan string acak apa saja.

```bash
npm run dev
```
Backend akan berjalan di `http://localhost:5000`.

### 3. Jalankan Frontend
Buka terminal baru:
```bash
cd frontend
npm install
cp .env.example .env
npm start
```
Frontend akan otomatis terbuka di `http://localhost:3000`.

### 4. Membuat Akun Admin
Secara default, semua akun baru terdaftar sebagai `user` biasa. Untuk membuat akun admin:
1. Daftar akun seperti biasa lewat halaman Register.
2. Buka database MongoDB kamu (via MongoDB Compass atau Atlas), cari collection `users`.
3. Ubah field `role` dari user tersebut menjadi `"admin"`.
4. Login ulang — menu "Admin" akan muncul di navbar.

## Menambah Fitur Selanjutnya (Saran)
- Payment gateway (Midtrans/Xendit) untuk pembayaran online
- Upload gambar produk (Cloudinary/multer) daripada input URL manual
- Riwayat pesanan lebih detail untuk user
- Notifikasi email saat status pesanan berubah
- Pagination & filter kategori di halaman katalog

## Catatan Keamanan
Sebelum deploy ke production:
- Ganti `JWT_SECRET` dengan string acak yang kuat
- Jangan commit file `.env` ke git (sudah ada `.gitignore` bawaan)
- Tambahkan validasi input lebih ketat di backend
