import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import API from '../api/axios';

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, clearCart, totalPrice } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [address, setAddress] = useState('');
  const [placing, setPlacing] = useState(false);
  const [message, setMessage] = useState('');

  const handleCheckout = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!address.trim()) {
      setMessage('Isi alamat pengiriman terlebih dahulu.');
      return;
    }

    setPlacing(true);
    try {
      const items = cartItems.map((item) => ({ productId: item._id, quantity: item.quantity }));
      await API.post('/orders', { items, shippingAddress: address });
      clearCart();
      setMessage('✅ Pesanan berhasil dibuat!');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Gagal membuat pesanan');
    }
    setPlacing(false);
  };

  if (cartItems.length === 0) {
    return <div style={{ padding: '24px' }}><p>Keranjang belanja kosong.</p>{message && <p>{message}</p>}</div>;
  }

  return (
    <div style={{ padding: '24px', maxWidth: '600px' }}>
      <h2>Keranjang Belanja</h2>
      {cartItems.map((item) => (
        <div key={item._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #e5e7eb' }}>
          <div>
            <p style={{ fontWeight: '600' }}>{item.name}</p>
            <p>Rp {item.price.toLocaleString('id-ID')}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <input
              type="number"
              min="1"
              value={item.quantity}
              onChange={(e) => updateQuantity(item._id, Number(e.target.value))}
              style={{ width: '50px', padding: '4px' }}
            />
            <button onClick={() => removeFromCart(item._id)} style={{ color: 'red', border: 'none', background: 'none', cursor: 'pointer' }}>
              Hapus
            </button>
          </div>
        </div>
      ))}

      <h3 style={{ marginTop: '16px' }}>Total: Rp {totalPrice.toLocaleString('id-ID')}</h3>

      <textarea
        placeholder="Alamat pengiriman lengkap..."
        value={address}
        onChange={(e) => setAddress(e.target.value)}
        style={{ width: '100%', minHeight: '80px', marginTop: '12px', padding: '8px' }}
      />

      {message && <p>{message}</p>}

      <button
        onClick={handleCheckout}
        disabled={placing}
        style={{ marginTop: '12px', padding: '10px 24px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
      >
        {placing ? 'Memproses...' : 'Buat Pesanan'}
      </button>
    </div>
  );
};

export default Cart;
