import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api/axios';
import { useCart } from '../context/CartContext';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      const { data } = await API.get(`/products/${id}`);
      setProduct(data);
    };
    fetchProduct();
  }, [id]);

  if (!product) return <p style={{ padding: '24px' }}>Memuat...</p>;

  const handleAddToCart = () => {
    addToCart(product, qty);
    navigate('/cart');
  };

  return (
    <div style={{ padding: '24px', display: 'flex', gap: '32px', flexWrap: 'wrap' }}>
      <img src={product.image} alt={product.name} style={{ width: '320px', borderRadius: '10px', objectFit: 'cover' }} />
      <div style={{ maxWidth: '480px' }}>
        <h2>{product.name}</h2>
        <p style={{ color: '#2563eb', fontSize: '22px', fontWeight: 'bold' }}>
          Rp {product.price.toLocaleString('id-ID')}
        </p>
        <p>{product.description}</p>
        <p>Kategori: {product.category}</p>
        <p>Stok tersedia: {product.stock}</p>

        {product.stock > 0 ? (
          <div style={{ marginTop: '16px' }}>
            <input
              type="number"
              min="1"
              max={product.stock}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value))}
              style={{ width: '60px', padding: '6px', marginRight: '10px' }}
            />
            <button
              onClick={handleAddToCart}
              style={{ padding: '10px 20px', background: '#16a34a', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
            >
              Tambah ke Keranjang
            </button>
          </div>
        ) : (
          <p style={{ color: 'red' }}>Stok habis</p>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
