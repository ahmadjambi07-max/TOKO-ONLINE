import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../../api/axios';

const emptyForm = { name: '', description: '', price: '', image: '', category: '', stock: '' };

const ProductForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = id && id !== 'new';
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (isEdit) {
      API.get(`/products/${id}`).then(({ data }) => setForm(data));
    }
  }, [id, isEdit]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = { ...form, price: Number(form.price), stock: Number(form.stock) };
    if (isEdit) {
      await API.put(`/products/${id}`, payload);
    } else {
      await API.post('/products', payload);
    }
    navigate('/admin');
  };

  return (
    <div style={{ padding: '24px', maxWidth: '480px' }}>
      <h2>{isEdit ? 'Edit Produk' : 'Tambah Produk'}</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Nama produk" value={form.name} onChange={handleChange} required style={inputStyle} />
        <textarea name="description" placeholder="Deskripsi" value={form.description} onChange={handleChange} required style={inputStyle} />
        <input name="price" type="number" placeholder="Harga" value={form.price} onChange={handleChange} required style={inputStyle} />
        <input name="image" placeholder="URL gambar" value={form.image} onChange={handleChange} style={inputStyle} />
        <input name="category" placeholder="Kategori" value={form.category} onChange={handleChange} style={inputStyle} />
        <input name="stock" type="number" placeholder="Stok" value={form.stock} onChange={handleChange} required style={inputStyle} />
        <button type="submit" style={btnStyle}>{isEdit ? 'Simpan Perubahan' : 'Tambah Produk'}</button>
      </form>
    </div>
  );
};

const inputStyle = { width: '100%', padding: '10px', marginBottom: '10px', border: '1px solid #d1d5db', borderRadius: '6px' };
const btnStyle = { width: '100%', padding: '10px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' };

export default ProductForm;
