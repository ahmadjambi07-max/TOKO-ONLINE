import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import API from '../../api/axios';

const Dashboard = () => {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [tab, setTab] = useState('produk');

  const fetchProducts = async () => {
    const { data } = await API.get('/products');
    setProducts(data);
  };

  const fetchOrders = async () => {
    const { data } = await API.get('/orders');
    setOrders(data);
  };

  useEffect(() => {
    fetchProducts();
    fetchOrders();
  }, []);

  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Yakin hapus produk ini?')) return;
    await API.delete(`/products/${id}`);
    fetchProducts();
  };

  const handleStatusChange = async (id, status) => {
    await API.put(`/orders/${id}/status`, { status });
    fetchOrders();
  };

  return (
    <div style={{ padding: '24px' }}>
      <h2>Dashboard Admin</h2>
      <div style={{ marginBottom: '20px' }}>
        <button onClick={() => setTab('produk')} style={tabBtn(tab === 'produk')}>Produk</button>
        <button onClick={() => setTab('pesanan')} style={tabBtn(tab === 'pesanan')}>Pesanan</button>
      </div>

      {tab === 'produk' && (
        <div>
          <Link to="/admin/product/new" style={{ display: 'inline-block', marginBottom: '16px', padding: '8px 16px', background: '#16a34a', color: '#fff', borderRadius: '6px', textDecoration: 'none' }}>
            + Tambah Produk
          </Link>
          <table style={tableStyle}>
            <thead>
              <tr>
                <th style={th}>Nama</th>
                <th style={th}>Harga</th>
                <th style={th}>Stok</th>
                <th style={th}>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p._id}>
                  <td style={td}>{p.name}</td>
                  <td style={td}>Rp {p.price.toLocaleString('id-ID')}</td>
                  <td style={td}>{p.stock}</td>
                  <td style={td}>
                    <Link to={`/admin/product/${p._id}`} style={{ marginRight: '10px' }}>Edit</Link>
                    <button onClick={() => handleDeleteProduct(p._id)} style={{ color: 'red', border: 'none', background: 'none', cursor: 'pointer' }}>Hapus</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'pesanan' && (
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={th}>Pemesan</th>
              <th style={th}>Total</th>
              <th style={th}>Status</th>
              <th style={th}>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o._id}>
                <td style={td}>{o.user?.name} <br /><small>{o.user?.email}</small></td>
                <td style={td}>Rp {o.totalPrice.toLocaleString('id-ID')}</td>
                <td style={td}>
                  <select value={o.status} onChange={(e) => handleStatusChange(o._id, e.target.value)}>
                    <option value="pending">Pending</option>
                    <option value="diproses">Diproses</option>
                    <option value="dikirim">Dikirim</option>
                    <option value="selesai">Selesai</option>
                    <option value="dibatalkan">Dibatalkan</option>
                  </select>
                </td>
                <td style={td}>{new Date(o.createdAt).toLocaleDateString('id-ID')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

const tabBtn = (active) => ({
  padding: '8px 16px',
  marginRight: '10px',
  border: 'none',
  borderRadius: '6px',
  background: active ? '#2563eb' : '#e5e7eb',
  color: active ? '#fff' : '#111827',
  cursor: 'pointer',
});
const tableStyle = { width: '100%', borderCollapse: 'collapse' };
const th = { textAlign: 'left', borderBottom: '2px solid #e5e7eb', padding: '10px' };
const td = { borderBottom: '1px solid #f3f4f6', padding: '10px' };

export default Dashboard;
