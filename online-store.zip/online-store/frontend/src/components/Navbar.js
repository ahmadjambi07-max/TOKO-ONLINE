import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const totalQty = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.brand}>🛍️ Toko Online</Link>
      <div style={styles.links}>
        <Link to="/" style={styles.link}>Produk</Link>
        <Link to="/cart" style={styles.link}>Keranjang ({totalQty})</Link>
        {user?.role === 'admin' && (
          <Link to="/admin" style={styles.link}>Admin</Link>
        )}
        {user ? (
          <>
            <span style={styles.link}>Hai, {user.name}</span>
            <button onClick={handleLogout} style={styles.btn}>Keluar</button>
          </>
        ) : (
          <Link to="/login" style={styles.link}>Masuk</Link>
        )}
      </div>
    </nav>
  );
};

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '14px 24px',
    background: '#1f2937',
    color: '#fff',
  },
  brand: { color: '#fff', fontWeight: 'bold', fontSize: '20px', textDecoration: 'none' },
  links: { display: 'flex', alignItems: 'center', gap: '18px' },
  link: { color: '#fff', textDecoration: 'none' },
  btn: {
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    padding: '6px 12px',
    borderRadius: '6px',
    cursor: 'pointer',
  },
};

export default Navbar;
