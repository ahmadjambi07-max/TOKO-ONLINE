import { Link } from 'react-router-dom';

const ProductCard = ({ product }) => {
  return (
    <div style={styles.card}>
      <Link to={`/product/${product._id}`}>
        <img src={product.image} alt={product.name} style={styles.img} />
      </Link>
      <div style={styles.body}>
        <Link to={`/product/${product._id}`} style={styles.name}>{product.name}</Link>
        <p style={styles.price}>Rp {product.price.toLocaleString('id-ID')}</p>
        <p style={styles.stock}>
          {product.stock > 0 ? `Stok: ${product.stock}` : 'Stok habis'}
        </p>
      </div>
    </div>
  );
};

const styles = {
  card: {
    border: '1px solid #e5e7eb',
    borderRadius: '10px',
    overflow: 'hidden',
    background: '#fff',
    display: 'flex',
    flexDirection: 'column',
  },
  img: { width: '100%', height: '160px', objectFit: 'cover' },
  body: { padding: '12px' },
  name: { fontWeight: '600', color: '#111827', textDecoration: 'none', display: 'block', marginBottom: '6px' },
  price: { color: '#2563eb', fontWeight: 'bold', margin: '4px 0' },
  stock: { fontSize: '13px', color: '#6b7280' },
};

export default ProductCard;
