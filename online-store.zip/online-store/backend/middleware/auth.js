const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Middleware untuk memastikan user sudah login (punya token valid)
const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
      next();
    } catch (err) {
      res.status(401).json({ message: 'Token tidak valid, akses ditolak' });
    }
  } else {
    res.status(401).json({ message: 'Tidak ada token, akses ditolak' });
  }
};

module.exports = { protect };
