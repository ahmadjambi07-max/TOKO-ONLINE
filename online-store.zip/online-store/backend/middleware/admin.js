// Middleware untuk membatasi akses hanya untuk admin
const admin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Akses ditolak, khusus admin' });
  }
};

module.exports = { admin };
